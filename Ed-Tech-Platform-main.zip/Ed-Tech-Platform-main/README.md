Some images of the application

HomePage

![homePage](https://github.com/Aditya1979314/EduPoint-Edtech-platform-/blob/53f06be44e1ce22a76efae58d9691a95c561badc/frontend/src/appimages/homePage.png)

CoursePage

![coursePage](https://github.com/Aditya1979314/EduPoint-Edtech-platform-/blob/7ef62f85a95569b0b97204a1e7ce1cdb025cb52c/frontend/src/appimages/coursePage.png)

PurchasedCoursePage

![PurchasedCourse](https://github.com/Aditya1979314/EduPoint-Edtech-platform-/blob/7ef62f85a95569b0b97204a1e7ce1cdb025cb52c/frontend/src/appimages/purchasedCourse.png)

Signup User Page

![signup page](https://github.com/Aditya1979314/EduPoint-Edtech-platform-/blob/7ef62f85a95569b0b97204a1e7ce1cdb025cb52c/frontend/src/appimages/signupUser.png)

Login User Page

![loginuser](https://github.com/Aditya1979314/EduPoint-Edtech-platform-/blob/7ef62f85a95569b0b97204a1e7ce1cdb025cb52c/frontend/src/appimages/loginUser.png)

Admin Course Publishing Page

![Admin course publish](https://github.com/Aditya1979314/EduPoint-Edtech-platform-/blob/7ef62f85a95569b0b97204a1e7ce1cdb025cb52c/frontend/src/appimages/adminpublishcourse.png)

Admin Courses Page

![admin courses](https://github.com/Aditya1979314/EduPoint-Edtech-platform-/blob/7ef62f85a95569b0b97204a1e7ce1cdb025cb52c/frontend/src/appimages/adminCourse.png)

Admin edit course page

![admin edit course page](https://github.com/Aditya1979314/EduPoint-Edtech-platform-/blob/7ef62f85a95569b0b97204a1e7ce1cdb025cb52c/frontend/src/appimages/admineditcourse.png)
