const data = [
  {
    id: 1,
    title: "first course",
    description:"Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley",
    image:"../images/react-image.png",
    price:"₹500"

},{
  id: 2,
  title: "first course",
  description:"Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley",
  image:"../images/react-image.png",
  price:"₹500"

},{
  id: 3,
  title: "first course",
  description:"Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley",
  image:"../images/react-image.png",
  price:"₹500"

},{
  id: 4,
  title: "first course",
  description:"Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley",
  image:"../images/react-image.png",
  price:"₹500"

},
];

module.exports = { data };
