export default function Video({src}){
    return (
        <video src={src} className="w-32 h-32"/>
    )
}